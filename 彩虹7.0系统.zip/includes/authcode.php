<?php
$authcode='32e6bb722005f113d4c2b759cf8559e3';
$distid='0';

?>